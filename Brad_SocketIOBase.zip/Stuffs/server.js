var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var checkword = require('check-word');
var words = checkword('en');
var Stopwatch = require('timer-stopwatch');

app.get('/', function(req,res){
    res.sendfile('index.html');
});

app.get('/checkword/:id', function(req,res){
	res.send(words.check(req.params.id));
});

io.on('connection', function(socket){
    console.log('A user connected');
    console.log(Object.keys(io.sockets.sockets).length);
    
    //setTimeout(function(){
    //    socket.send('Hello from the Server!');
    //}, 4000);
    
    socket.on('clientTest', function(data) {
        console.log(data);
        
        console.log(words.check(data.toLowerCase()));
        
        socket.emit('wordResponse', 'Your word is ' + words.check(data.toLowerCase()));
        
        //socket.send('Your word is ' + words.check(data.toLowerCase()));
        
    })
    
    socket.on('startClock', function(){
        var timer = new Stopwatch(30000);
        
        timer.start();
        
        timer.onTime(function(time){
            console.log(time.ms);
            io.sockets.emit('timeLeft','Time left: ' + time.ms);
        })
        
        timer.onDone(function(){
            console.log('we done bitches');
            socket.emit('TIMES UP MUDDA');
        })
    })
    
    
    socket.on('disconnect', function(){
        console.log('Fuckity bye!');
    });
});

http.listen(3000, function(){
    console.log('listening on *:3000');
});